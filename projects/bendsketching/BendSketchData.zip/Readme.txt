The supplemental data for the paper "BendSketch: Modeling Freeform Surfaces Through 2D Sketching" contains three files:

SupplementalResults.pdf - more models created with the new method.

UserEvaluation.pdf - details of the user evaluation about the new sketch-based modeling system.

3d_mesh_models.zip - 10 3D models created through our method.